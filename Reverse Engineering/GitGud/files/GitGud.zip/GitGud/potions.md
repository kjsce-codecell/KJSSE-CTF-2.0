# Potions

## Invisibility Potion

- **Ingredients:**
  - 3 unicorn hairs
  - 1 vial of wormwood
  - 2 drops of leprechaun's blood
- **Effect:** Grants the drinker invisibility for a few hours.

## Felix Felicis

- **Ingredients:**
  - 7 lucky stars
  - 1 bottle of butterbeer
  - 3 drops of dragon's blood
- **Effect:** Grants the drinker good luck for a limited time.

## Polyjuice Potion

- **Ingredients:**
  - 2 rat tails
  - 3 spider eyes
  - 1 hair of the person to transform into
- **Effect:** Allows the drinker to take on the appearance of another person.

## Veritaserum

- **Ingredients:**
  - 5 drops of truth serum
  - 1 sprig of mint
  - 3 drops of elf tears
- **Effect:** Forces the drinker to tell the truth.

## Amortentia

- **Ingredients:**
  - Unknown, highly complex
- **Effect:** The most powerful love potion, with effects unique to each individual.

## Wolfsbane Potion

- **Ingredients:**
  - 10 wolfsbane flowers
  - 3 drops of wolfsbane extract
  - 1 vial of moonstone essence
- **Effect:** Eases the effects of lycanthropy, allowing the drinker to retain their mind during transformation.

// Remember to handle potions with care and only use them for good purposes
